<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Articulo_s extends Model
{
    protected $table = 'articulos_s';
    protected $primaryKey = 'claart';
}
