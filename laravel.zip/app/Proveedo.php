<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proveedo extends Model
{
    protected $table = 'proveedo';
    protected $primaryKey = 'clapro';
}
