<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Familia_s extends Model
{
    protected $table = 'familias_s';
    protected $primaryKey = 'clafam';
}
