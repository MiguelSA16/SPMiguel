<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Movalm extends Model
{
    protected $table = 'movalm';
}
