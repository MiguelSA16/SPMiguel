<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Familia_clg extends Model
{
    protected $table = 'familia_clg';
    protected $primaryKey = 'clafam';
}
