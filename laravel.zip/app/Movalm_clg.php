<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Movalm_clg extends Model
{
    protected $table = 'movalm_clg';
    protected $primaryKey = 'clamov';
}
