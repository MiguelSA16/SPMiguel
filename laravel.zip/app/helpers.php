<?php

use App\Articulo;
use App\Cliente;

function setShow($routeName){



        return request()->routeIs($routeName) ? 'show' : '';

    }



    function setactive($routeName){



        return request()->routeIs($routeName) ? 'active' : '';

    }

    function nombreArticulo($ref){
        
        $articulo = Articulo::where('codigo', $ref)->first();
        return $articulo->nombre;
    }

    function nombreCliente($clacli){
        $cliente =  Cliente::where('clacli',$clacli)->first();
        return $cliente->nombre;
    }
    
    function nombreClientex($clacli){
        $cliente =  Cliente::where('clacli',$clacli)->first();
        $nombreCortado = substr( $cliente->nombre, 0,10);   
        return  $nombreCortado ;
    }