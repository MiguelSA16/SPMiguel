<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Articulo_clg extends Model
{
    protected $table = 'articulos_clg';
    protected $primaryKey = 'claart';
}
