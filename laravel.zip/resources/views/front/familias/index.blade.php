@extends('layouts.front.vertical')

@section('titulo')
    Nuestros Productos
@endsection

@section('cuerpo')
    @include('comun.front.camino-migas')
    @include('comun.front.familias')
    @include('comun.front.carusel-items')
    
@endsection