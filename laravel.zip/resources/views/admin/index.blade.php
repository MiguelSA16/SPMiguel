@extends('layouts.admin.nav-left')

@section('cuerpo')
    <p>
        estas en el cuerpoo de index
    </p>
@endsection