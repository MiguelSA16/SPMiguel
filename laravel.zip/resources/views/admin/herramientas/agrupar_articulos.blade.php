@extends('layouts.admin.nav-left')

@section('cuerpo')
    <v-agrupar-articulo/>
@endsection