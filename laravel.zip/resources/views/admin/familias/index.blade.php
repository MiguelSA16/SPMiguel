@extends('layouts.admin.nav-left')

@section('cuerpo')
    <v-familias/>
    
@endsection