@extends('layouts.admin.nav-left')

@section('cuerpo')
    <v-articulos-fabricacion/>
@endsection