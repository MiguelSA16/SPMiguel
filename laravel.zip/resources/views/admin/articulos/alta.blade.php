@extends('layouts.admin.nav-left')

@section('cuerpo')
    <v-articulos-alta/>
@endsection