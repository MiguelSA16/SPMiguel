

<?php $__env->startSection('cuerpo'); ?>
    <p>
        estas en el cuerpoo de index
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.nav-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gj1ldjyb/public_html/laravel/resources/views/admin/index.blade.php ENDPATH**/ ?>