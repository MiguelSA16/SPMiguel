<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/gj1ldjyb/public_html/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>