<?php echo e($slot); ?>

<?php /**PATH /home/gj1ldjyb/public_html/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>