<!DOCTYPE html>
<html lang="ES-es">
<head><meta charset="gb18030">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table cellpadding="0" cellspacing="0" border="0" align="center" width="600" class="container">
        <tr>
            <td width="100%" colspan="3" align="center">
                <div align='center'>
                    <img src="http://127.0.0.1:8000//images/logo.png" width="300">
                </div>
            </td>
        </tr>
        <tr>
            <td width="100">&nbsp;</td>
            <td width="400">
                <div align='left' >
                    <p> 
                        Hola, <br/><br/>
                        ¡Genial! Te has suscrito a los newsletters de Sunpro Redes y Sistemas.
                        Te queda solo un paso para hacerlo oficial: por favor, confirma tu suscripción.
                    </p>
                </div>
            </td>
            <td width="100">&nbsp;</td>
        </tr>
        <tr>
            <td height="42" width="100">&nbsp;</td>
            <td width="400" bgcolor="#dc1b22" align="center" >
                <a href="http://www.sunprored.es/confirmar-newletter/<?php echo e($datos->email); ?>" style="color:#fff; text-decoration:none; font-size:16px;">
                    ACTIVAR MI CUENTA
                </a>
            </td>
            <td height="42" width="100">&nbsp;</td>
        </tr>
    </table>
</body>
</html><?php /**PATH /home/gj1ldjyb/public_html/laravel/resources/views/emails/newsletter.blade.php ENDPATH**/ ?>