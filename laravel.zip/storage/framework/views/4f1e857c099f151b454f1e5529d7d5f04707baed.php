<?php $__env->startSection('cuerpo'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.incidencia.incidencia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\SunproPrivado\resources\views/front/operario/listar-incidencias.blade.php ENDPATH**/ ?>