

<?php $__env->startSection('cuerpo'); ?>
    <v-articulos-alta/>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.nav-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gj1ldjyb/public_html/laravel/resources/views/admin/articulos/alta.blade.php ENDPATH**/ ?>