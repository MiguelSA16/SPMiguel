<footer class="sticky-footer bg-sunpro py-3">
    <div class="container my-auto">
        <div class="copyright text-center my-auto text-white">
            <span>Copyright &copy; 2018 Sunpro Redes y Sistemas SL.</span>
        </div>
    </div>
</footer><?php /**PATH /home/gj1ldjyb/public_html/laravel/resources/views/comun/admin/footer.blade.php ENDPATH**/ ?>