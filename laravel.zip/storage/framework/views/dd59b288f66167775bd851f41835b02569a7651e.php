<?php $__env->startSection('cuerpo'); ?>
    <v-users/>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.nav-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\SPMiguel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>